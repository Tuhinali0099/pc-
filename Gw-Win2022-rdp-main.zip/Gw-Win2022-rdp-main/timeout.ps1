$i = 3600
do {
    Write-Host $i
    Sleep 3600
    $i--
} while ($i -gt 0)
